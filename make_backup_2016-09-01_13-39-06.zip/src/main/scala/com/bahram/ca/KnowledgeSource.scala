package com.bahram.ca

import com.bahram.socialfabric.Individual

/**
  * Created by zaeri on 02/08/16.
  */
abstract class KnowledgeSource {

  def update(population: Array[Individual], fitness: (Array[Double] => Double)): Array[Individual]

  def compareAsc(i1: Individual, i2: Individual): Boolean = i1.fitnessValue < i2.fitnessValue


}
