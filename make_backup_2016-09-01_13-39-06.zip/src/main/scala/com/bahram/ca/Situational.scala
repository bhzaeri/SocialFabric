package com.bahram.ca

import com.bahram.socialfabric.Individual
import com.bahram.util.RandomUtil

/**
  * Created by zaeri on 02/08/16.
  */
class Situational extends KnowledgeSource {
  var best: Individual = _

  override def update(population: Array[Individual], fitness: Array[Double] => Double): Array[Individual] = {


    scala.util.Sorting.stableSort[Individual](population, compareAsc _)

    if (best == null || population(0).fitnessValue < best.fitnessValue) {
      best = population(0)
    }
    val s: Int = (0.2 * population.length).asInstanceOf[Int]
    val offSprings = new Array[Individual](s)
    for (i <- 0 until s) {
      offSprings(i) = population(i).copy()
      val t = offSprings(i)
      for (j <- t.vector.indices) {
        if (population(i).vector(j) < best.vector(j))
          t.vector(j) = population(i).vector(j) + (best.vector(j) - population(i).vector(j)) * RandomUtil.nextDouble()
        else
          t.vector(j) = population(i).vector(j) - (population(i).vector(j) - best.vector(j)) * RandomUtil.nextDouble()

        if (t.vector(j) < Config.lowerBound)
          t.vector(j) = Config.lowerBound
        if (t.vector(j) > Config.upperBound)
          t.vector(j) = Config.upperBound

      }
      t.fitnessValue = fitness(t.vector)
      t.ksType = KSEnum.SITUATIONAL
    }

    val length = population.length
    val population2 = population ++ offSprings

    scala.util.Sorting.stableSort[Individual](population2, compareAsc _)
    population2.slice(0, length)
  }
}
