package com.bahram.ca

import com.bahram.socialfabric.Individual
import com.bahram.util.RandomUtil

import scala.collection.immutable.HashMap
import scala.util.control.Breaks

/**
  * Created by zaeri on 03/08/16.
  */
class CAModule {
  val knowledgeSources: Map[KSEnum.Value, KnowledgeSource] = Map(KSEnum.SITUATIONAL -> new Situational, KSEnum.NORMATIVE -> new Normative, KSEnum.TOPOGRAPHIC -> new Topographic)
  val wSize = 20

  def update(population: Array[Individual], fitness: (Array[Double] => Double)): Array[Individual] = {
    var temp = new HashMap[KSEnum.Value, Double]
    var sum = 0.0
    population.foreach(p => {
      var t = 1 / p.fitnessValue
      var tt = 0.0
      if (temp.keySet.contains(p.ksType))
        tt = temp(p.ksType)
      temp += (p.ksType -> (tt + t))
      sum += t
    })
    val r = RandomUtil.nextDouble() * sum
    var t = 0.0
    val bb = new Breaks()
    var ks: KSEnum.Value = null
    bb.breakable {
      temp.foreach((pair) => {
        if (r >= t && r <= t + pair._2) {
          ks = pair._1
          bb.break
        }
        else
          t += pair._2
      })
    }
    knowledgeSources(ks).update(population, fitness)
  }
}

object KSEnum extends Enumeration {
  val SITUATIONAL, NORMATIVE, TOPOGRAPHIC = Value
}