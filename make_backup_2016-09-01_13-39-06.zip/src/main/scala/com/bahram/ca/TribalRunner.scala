package main.scala.com.bahram.ca

import com.bahram.ca._
import com.bahram.pso.PSOFactory
import com.bahram.socialfabric.topology.{TopologyEnum, TopologyFactory}
import com.bahram.socialfabric.{Individual, Neighborhood}

import scala.collection.mutable.ArrayBuffer

/**
  * Created by zaeri on 24/08/16.
  */
object TribalRunner {

  var tribes: Array[Neighborhood] = null

  def run(): Unit = {
    val popSize = 10
    configure
    tribes = Array.fill[Neighborhood](10) {
      new Neighborhood(PSOFactory.population(Config.makePopulation(popSize), Config.extra, Config.fitness),
        TopologyFactory.create(Config.topologyType, popSize))
    }
    while (Config.countFEs <= Config.maxFEs) {
      tribes.foreach(tribe => {
        Config.calculateNewPopulation(tribe)
      })

      tribes.foreach(tribe => {
        Config.applyNewPosition(Config.fitness, tribe)
      })
      Config.iter += 1

      tribes.foreach(tribe => {
        Config.applyCA(Config.iter, tribe, Config.fitness)
      })
      if (Config.thirdPhase && tribes.length > 1)
        tribes = Array.fill[Neighborhood](1) {
          unify()
        }
    }
  }

  def unify(): Neighborhood = {
    var all = new ArrayBuffer[Individual]()
    tribes.foreach(tribe => {
      all ++= tribe.individuals
    })
    new Neighborhood(all.toArray, TopologyFactory.create(TopologyEnum.GLOBAL, all.size))
  }

  def findIntraTribalBest(): Individual = {
    var minValue = Double.MaxValue
    var best: Individual = null
    tribes.foreach(n => {
      val temp = n.findBestIndividual()
      if (temp.fitnessValue < minValue) {
        minValue = temp.fitnessValue
        best = temp
      }
    })
    best
  }

}
