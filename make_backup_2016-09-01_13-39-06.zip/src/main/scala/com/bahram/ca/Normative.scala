package com.bahram.ca

import com.bahram.socialfabric.Individual
import com.bahram.socialfabric.topology.TopologyFactory
import main.java.com.bahram.ca.NormativeUpdate


/**
  * Created by zaeri on 02/08/16.
  */
class Normative() extends KnowledgeSource {

  var best: Individual = _
  var lb = Array.fill[Double](TopologyFactory.dimension)(Double.MaxValue)
  var ub = Array.fill[Double](TopologyFactory.dimension)(Double.MinValue)
  var pl = Array.fill[Double](TopologyFactory.dimension)(Double.MaxValue)
  var pu = Array.fill[Double](TopologyFactory.dimension)(Double.MinValue)

  override def update(population: Array[Individual], fitness: (Array[Double]) => Double): Array[Individual] = {
    scala.util.Sorting.stableSort[Individual](population, compareAsc _)

    if (best == null || population(0).fitnessValue < best.fitnessValue) {
      best = population(0)
    }
    val s: Int = (0.2 * population.length).asInstanceOf[Int]
    for (i <- 0 until s) {
      val t = population(i)
      for (j <- t.vector.indices) {
        if (t.vector(j) <= lb(j) || t.fitnessValue < pu(j)) {
          lb(j) = t.vector(j)
          pl(j) = t.fitnessValue
        }
        if (t.vector(j) >= ub(j) || t.fitnessValue < pu(j)) {
          ub(j) = t.vector(j)
          pu(j) = t.fitnessValue
        }
      }
    }
    var sum = 0.0
    population.foreach(sum += _.fitnessValue)
    val offSprings = new Array[Individual](s)
    for (i <- 0 until s) {
      offSprings(i) = population(i).copy()
      val t = offSprings(i)
      val parent = population(i)

      NormativeUpdate.update2(t, best, parent, this)

      t.ksType = KSEnum.NORMATIVE
    }

    val length = population.length
    val population2: Array[Individual] = population ++ offSprings

    scala.util.Sorting.stableSort[Individual](population2, compareAsc _)
    population2.slice(0, length)
  }
}
