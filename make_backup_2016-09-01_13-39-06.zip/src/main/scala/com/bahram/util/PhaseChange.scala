package com.bahram.util

import com.bahram.ca._

/**
  * Created by zaeri on 24/08/16.
  */
object PhaseChange {
  val phases = Array(0.2, 0.5)
  var index = 0

  def checkChange() = {
    if (index < phases.length && Config.countFEs == (phases(index) * Config.maxFEs).asInstanceOf[Int]) {
      Config.secondPhase = !Config.secondPhase
      index += 1
      if (index == 2)
        Config.thirdPhase = true
    }
  }
}

