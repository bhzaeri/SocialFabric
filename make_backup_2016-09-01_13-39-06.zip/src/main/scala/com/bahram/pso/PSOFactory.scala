package com.bahram.pso

import com.bahram.ca.Config
import com.bahram.socialfabric.topology.TopologyFactory
import com.bahram.socialfabric.{Individual, Neighborhood}
import com.bahram.util.RandomUtil
import org.apache.log4j.Logger

object PSOFactory {

  val logger = Logger.getLogger(this.getClass)

  def pso1(self: Particle, best: Particle) = {
    val dimSize = self.vector.length
    val c1 = 2.0
    val c2 = 2.0
    for (d <- 0 until dimSize) {
      val r1 = RandomUtil.nextDouble()
      val r2 = RandomUtil.nextDouble()
      self.velocity(d) = self.velocity(d) + r1 * c1 * (self.bestVector(d) - self.vector(d)) + r2 * c2 * (best.vector(d) - self.vector(d))
    }
  }

  def applyNormalCA(iteration: Int, neighborhood: Neighborhood, fitness: (Array[Double] => Double)): Unit = {
    if (iteration % neighborhood.cAModule.wSize == 0) {
      val newPop = neighborhood.cAModule.update(neighborhood.individuals, fitness)
      neighborhood.individuals = newPop
    }
  }

  def applySocialFabric(iteration: Int, neighborhood: Neighborhood, fitness: (Array[Double] => Double)): Unit = {
  }

  def population(result: Array[Individual], extra: (Individual => Unit), fitness: (Array[Double] => Double)): Array[Individual] = {
    val rand = RandomUtil
    val size = result.length
    for (i <- 0 until size) {
      val p = result(i) // new Particle(dimension);
      val vector = new Array[Double](TopologyFactory.dimension)
      for (j <- vector.indices) {
        vector(j) = rand.nextDouble() * Config.upperBound + Config.lowerBound
      }
      p.vector_(vector)
      p.fitnessValue = fitness(vector)
      extra(p)
    }
    return result
  }
}