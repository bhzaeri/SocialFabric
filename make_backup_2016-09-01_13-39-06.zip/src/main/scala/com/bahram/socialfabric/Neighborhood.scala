package com.bahram.socialfabric

import com.bahram.ca._
import com.bahram.socialfabric.topology.Topology

class Neighborhood(_individuals: Array[Individual], t: Topology,caModule: CAModule) {

  var individuals = _individuals
  var topology: Topology = t
  var cAModule: CAModule = caModule
  private var best: Individual = null


  def evolutionStep(): Unit = {
    Config.evolutionStep(this, Config.fitness)
  }

  def getBestValueOfNeighborhood(index: Int): Double = {
    val i = this.getBestIndexOfNeighborhood(index)
    _individuals(i).fitnessValue
  }

  def getBestIndexOfNeighborhood(index: Int): Int = {
    val neighbors: Array[Int] = topology.getNeighbors(index)
    var min = Double.MaxValue
    var minIndex = -1
    neighbors foreach { i => {
      if (_individuals(i).fitnessValue < min) {
        minIndex = i
        min = _individuals(i).fitnessValue
      }
    }
    }
    minIndex
  }

  def getBestOfNeighborhood(index: Int): Individual = {
    val i = this.getBestIndexOfNeighborhood(index)
    _individuals(i)
  }

  def findBestIndividual(): Individual = {
    var bestValue = Double.MaxValue
    _individuals.foreach { x => {
      if (x.fitnessValue < bestValue) {
        bestValue = x.fitnessValue
        best = x
      }
    }
    }
    best
  }

  def getBestIndividual(): Individual = best

}