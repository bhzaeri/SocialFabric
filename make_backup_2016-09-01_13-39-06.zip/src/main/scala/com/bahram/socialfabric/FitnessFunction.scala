package com.bahram.socialfabric

trait FitnessFunction {
  def evaluate(vector: Array[Double]): Double
}