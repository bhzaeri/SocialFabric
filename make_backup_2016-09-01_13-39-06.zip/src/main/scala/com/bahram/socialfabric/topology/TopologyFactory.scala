package com.bahram.socialfabric.topology


object TopologyFactory {

  val dimension = 10

  def create(enum1: TopologyEnum.Value, size: Int): Topology = {
    enum1 match {
      case TopologyEnum.GLOBAL => new GlobalTopology(size)
      case TopologyEnum.MESH => new MeshTopology(size)
      case TopologyEnum.TREE => new TreeTopology(size)
      case TopologyEnum.RING => new RingTopology(size)
    }
  }
}

object TopologyEnum extends Enumeration {
  val GLOBAL, MESH, TREE, RING = Value
}
